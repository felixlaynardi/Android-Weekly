package umn.ac.week06_28641;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class PhysicsAnimation extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.physics_animation);
    }
}
